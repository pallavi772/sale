package com.worldline.dts.sale.SpringBatchJDBC;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.worldline.dts.sale.dataaccess.FailedSaleXmlIntermediate;
import com.worldline.dts.sale.dataaccess.FailedSaleXmlIntermediateRepository;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediate;

@Component
public class FailedSaleXmlWriter implements ItemWriter<SaleXmlIntermediate> {

	@Autowired
	private FailedSaleXmlIntermediateRepository failedSaleXmlIntermediateRepository;

	@Override
	public void write(List<? extends SaleXmlIntermediate> items) throws Exception {
		for (SaleXmlIntermediate saleXmlIntermediate : items) {

			FailedSaleXmlIntermediate failedRecord = new FailedSaleXmlIntermediate();

			failedRecord.setSaleId(saleXmlIntermediate.getSaleId());
			failedRecord.setOriginalId(saleXmlIntermediate.getOriginalId());
			failedRecord.setSaleXml(saleXmlIntermediate.getSaleXml());
			failedRecord.setCreatedDate(saleXmlIntermediate.getCreatedDate());
			failedRecord.setSaleLastUpdatedDate(saleXmlIntermediate.getSaleLastUpdatedDate());

			failedRecord.setProcessingAttempt(0);

			failedSaleXmlIntermediateRepository.save(failedRecord);

		}
	}    
}