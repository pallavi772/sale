package com.worldline.dts.sale.SpringBatchJDBC;

import java.util.Collections;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import com.worldline.dts.common.logger.DTSLogger;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediate;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediateRepository;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	private final SaleXmlReader reader;
	private final SaleXmlProcessor processor;
	private final SaleXmlWriter saleXmlwriter;
    private final PlatformTransactionManager transactionManager;
    private final StepBuilderFactory stepBuilderFactory;



	private static DTSLogger log = DTSLogger.getLogger(BatchConfiguration.class);

	@Autowired
	SaleXmlIntermediateRepository saleXmlIntermediateRepository;

	@Value("${batch.tasklet.limit}")
	private int taskletLimit;

	public BatchConfiguration(SaleXmlReader reader, SaleXmlProcessor processor, SaleXmlWriter saleXmlwriter, PlatformTransactionManager transactionManager,StepBuilderFactory stepBuilderFactory) {
		this.reader = reader;
		this.processor = processor;
		this.saleXmlwriter = saleXmlwriter;
        this.transactionManager = transactionManager;
        this.stepBuilderFactory = stepBuilderFactory;


	}

	@Bean
	public Job importSaleJob(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory) {
		return jobBuilderFactory.get("importSaleJob").incrementer(new RunIdIncrementer())
				.flow(importSaleStep())
				.end().build();
	}

	@Bean
	public Step importSaleStep() {
		return stepBuilderFactory.get("importSaleStep")
        .tasklet(importSaleTasklet(taskletLimit))
        .transactionManager(transactionManager)
        .build();
	}

	
	  @Bean
	    public Tasklet importSaleTasklet(int limit) {
	        return (contribution, chunkContext) -> {
	            JdbcCursorItemReader<SaleXmlIntermediate> reader = this.reader.reader();
	            reader.open(chunkContext.getStepContext().getStepExecution().getExecutionContext());
	            log.info(" ########### inside reader  " + reader);

	            SaleXmlIntermediate saleXmlIntermediate;

	            try {
	                // Process records up to the limit
	                for (int count = 0; count < limit; count++) {
	                    saleXmlIntermediate = reader.read();

	                    if (saleXmlIntermediate == null) {
	                        break;  // Stop if no more records
	                    }

	                    // Process the SaleXmlIntermediate data
	                    SaleXmlAndTransactionData processedData = processor.process(saleXmlIntermediate);
	                    log.info(" ########### inside processor " + processedData);

	                    try {
	                        if (processedData == null) {
	                            throw new RuntimeException(
	                                    "Processed data is null for Sale ID: " + saleXmlIntermediate.getSaleId());
	                        }

	                        // Write the processed data
	                        saleXmlwriter.write(Collections.singletonList(processedData));
		                    log.info(" ########### inside writer " + processedData);


	                    } catch (Exception e) {
	                        log.error("Failed to write processed data for Sale with ID: " + saleXmlIntermediate.getSaleId(), e);
	                    }
	                }
	            } finally {
	                // Close the reader
	                reader.close();
	            }

	            return RepeatStatus.FINISHED;
	        };
	    }
	}