package com.worldline.dts.sale.SpringBatchJDBC;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SaleProcessJobScheduler {

	private final JobLauncher jobLauncher;
	private final Job importSaleJob;

	@Autowired
	public SaleProcessJobScheduler(JobLauncher jobLauncher, @Qualifier("importSaleJob") Job importUserJob) {
		this.jobLauncher = jobLauncher;
		this.importSaleJob = importUserJob;
	}

	@Scheduled(fixedRate = 60000)
	public void scheduleJob() {
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.toJobParameters();
		try {
			jobLauncher.run(importSaleJob, jobParameters);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
