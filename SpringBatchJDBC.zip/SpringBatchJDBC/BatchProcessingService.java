package com.worldline.dts.sale.SpringBatchJDBC;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.worldline.dts.sale.dataaccess.SaleTransactionData;
import com.worldline.dts.sale.dataaccess.SaleTransactionDataRepository;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediate;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediateRepository;

@Service
public class BatchProcessingService {
	@Autowired
	private SaleXmlIntermediateRepository repository1;

	@Autowired
	private SaleTransactionDataRepository repository2;

	@Transactional
	public void processRecord(List<SaleTransactionData> entityB) {
		 BigInteger idToUpdateStatusInA = entityB.get(0).getSaleId();
		try {
			// Attempt to insert into Repository 2 (Table B)
			repository2.saveAll(entityB);
		} catch (Exception e) {
			// Log and handle the exception appropriately
			System.err.println("Error inserting into Repository 2: " + e.getMessage());
			// Proceed to update the status in Repository 1 (Table A)
			updateStatusInRepository1(idToUpdateStatusInA, 2);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateStatusInRepository1(BigInteger id, int status) {
		try {
			// Update the status in Repository 1 (Table A)
			SaleXmlIntermediate entityA = repository1.findBySaleId(id)
					.orElseThrow(() -> new EntityNotFoundException("Entity A not found for id: " + id));
			entityA.setIsProcessed(status);
			repository1.save(entityA);
		} catch (Exception e) {
			// Handle the exception without causing rollback on Repository 2
			System.err.println("Error updating Repository 1: " + e.getMessage());

		}
	}

}
