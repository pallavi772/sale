package com.worldline.dts.sale.SpringBatchJDBC;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.worldline.dts.sale.dataaccess.SaleNonIssueData;
import com.worldline.dts.sale.dataaccess.SaleRefundData;
import com.worldline.dts.sale.dataaccess.SaleReservationData;
import com.worldline.dts.sale.dataaccess.SaleSundriesData;
import com.worldline.dts.sale.dataaccess.SaleTicketData;
import com.worldline.dts.sale.dataaccess.SaleTransactionData;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediate;
import com.worldline.dts.sale.model.AdminFeeXml;
import com.worldline.dts.sale.model.NonIssuesXml;
import com.worldline.dts.sale.model.PaymentXml;
import com.worldline.dts.sale.model.RefundXml;
import com.worldline.dts.sale.model.ReservationDetailsXml;
import com.worldline.dts.sale.model.SaleXml;
import com.worldline.dts.sale.model.SundryXml;
import com.worldline.dts.sale.model.TicketXml;

@Component
public class SaleXmlProcessor implements ItemProcessor<SaleXmlIntermediate, SaleXmlAndTransactionData> {

	private static final String UNKNOWN_CLIENT_ID = "Unknown";
	private static final String UNKNOWN_RETAIL_CHANNEL = "Unknown";

	@Override
	public SaleXmlAndTransactionData process(SaleXmlIntermediate saleXmlIntermediate) throws Exception {
		  Logger logger = LoggerFactory.getLogger(SaleXmlProcessor.class);

		  String saleXmlContent = saleXmlIntermediate.getSaleXml();
		    logger.info("Processing SaleXmlIntermediate with content: {}", saleXmlContent);
		SaleXml saleXml;
		    try {
		        saleXml = new XmlMapper().readValue(saleXmlContent, SaleXml.class);
		    } catch (Exception e) {
		        logger.error("Error deserializing SaleXml: {}", e.getMessage());
		        throw e;
		    }
		
		SaleTransactionData saleTransactionData = createSaleTransactionData(saleXmlIntermediate, saleXml);

		setClientId(saleXml, saleTransactionData);
	    setRetailChannel(saleXml, saleTransactionData);
		setPaymentInfo(saleXml, saleTransactionData);
		setSaleDetails(saleXml, saleTransactionData);
		return new SaleXmlAndTransactionData(saleXmlIntermediate, saleTransactionData);

	}

	private SaleTransactionData createSaleTransactionData(SaleXmlIntermediate saleXmlIntermediate, SaleXml saleXml) {
		SaleTransactionData saleTransactionData = new SaleTransactionData();
		saleTransactionData.setSaleId(saleXmlIntermediate.getSaleId());
		saleTransactionData.setOriginalId(saleXmlIntermediate.getOriginalId());
		saleTransactionData.setCreatedDate(new Date());
		saleTransactionData.setBusinessGroup(saleXml.getBusinessGroup());
		saleTransactionData.setIssueMachine(saleXml.getIssueMachine());
		saleTransactionData.setIssueMachineType(saleXml.getIssueMachineType());
		saleTransactionData.setSaleIssueDate(saleXml.getSaleIssueDate());
		saleTransactionData.setSaleNumber(saleXml.getSaleNumber());
		saleTransactionData.setSaleLastUpdatedDate(saleXmlIntermediate.getSaleLastUpdatedDate());
		saleTransactionData.setIssueOffice(saleXml.getIssueOffice());
		saleTransactionData.setFulfilment(saleXml.getFulfilment());
		saleTransactionData.setContactBookingReference(saleXml.getContactBookingReference());
		saleTransactionData.setIssueWindow(saleXml.getIssueWindow());
		saleTransactionData.setCtrReference(saleXml.getCtrReference());
		saleTransactionData.setSaleIssueTime(saleXml.getSaleIssueTime());
		saleTransactionData.setSaleTransactionType(determineTransactionType(saleXml));
		saleTransactionData.setClientId(saleXml.getClientId());
		saleTransactionData.setRetailChannel(saleXml.getRetailChannel());
		return saleTransactionData;
	}

	private void setClientId(SaleXml saleXml, SaleTransactionData saleTransactionData) {
		saleTransactionData.setClientId(Optional.ofNullable(saleXml.getClientId()).orElse(UNKNOWN_CLIENT_ID));
	}

	private void setRetailChannel(SaleXml saleXml, SaleTransactionData saleTransactionData) {
		saleTransactionData
				.setRetailChannel(Optional.ofNullable(saleXml.getRetailChannel()).orElse(UNKNOWN_RETAIL_CHANNEL));
	}

	private void setPaymentInfo(SaleXml saleXml, SaleTransactionData saleTransactionData) {
		if (CollectionUtils.isNotEmpty(saleXml.getPayments())) {
			PaymentXml payment = saleXml.getPayments().get(0);
			saleTransactionData.setMop(payment.getMOP());
			saleTransactionData.setPaymentAmount(payment.getAmount());
		}
	}

	private void setSaleDetails(SaleXml saleXml, SaleTransactionData saleTransactionData) {
		if (CollectionUtils.isNotEmpty(saleXml.getTickets())) {
			saleTransactionData.setSaleTicketData(processTicket(saleXml.getTickets(), saleTransactionData));
		}
		if (CollectionUtils.isNotEmpty(saleXml.getSundries())) {
			saleTransactionData.setSaleSundriesData(processSundries(saleXml.getSundries(), saleTransactionData));
		}
		if (CollectionUtils.isNotEmpty(saleXml.getRefunds())) {
			saleTransactionData.setSaleRefundData(processRefund(saleXml.getRefunds(), saleTransactionData));
		}
		if (CollectionUtils.isNotEmpty(saleXml.getNonIssues())) {
			saleTransactionData.setSaleNonIssueData(processNonIssue(saleXml.getNonIssues(), saleTransactionData));
		}
	}

	private String determineTransactionType(SaleXml saleXml) {
		if (CollectionUtils.isNotEmpty(saleXml.getNonIssues())) {
			return "Non Issue Sale";
		} else if (CollectionUtils.isNotEmpty(saleXml.getRefunds())) {
			return "Refund Sale";
		} else if (CollectionUtils.isEmpty(saleXml.getTickets())) {
			return "TOD Sale";
		} else {
			return "Sale";
		}
	}

	private List<SaleSundriesData> processSundries(List<SundryXml> sundries, SaleTransactionData saleTransactionData) {
		List<SaleSundriesData> saleSundriesDataList = new ArrayList<>();
		for (SundryXml sundry : sundries) {
			saleSundriesDataList.add(createSaleSundriesData(sundry, saleTransactionData));
		}
		return saleSundriesDataList;
	}

	private SaleSundriesData createSaleSundriesData(SundryXml sundry, SaleTransactionData saleTransactionData) {
		SaleSundriesData saleSundriesData = new SaleSundriesData();
		saleSundriesData.setSundryCode(sundry.getSundryCode());
		saleSundriesData.setTransactionNumber(sundry.getTransactionNumber());
		saleSundriesData.setSundryFee(Integer.parseInt(sundry.getAmount()));
		saleSundriesData.setDebitCreditInd(sundry.getDebitCreditInd());
		saleSundriesData.setNumItems(Integer.parseInt(sundry.getNumItems()));
		saleSundriesData.setIssueDate(sundry.getIssueDate());
		saleSundriesData.setCreatedDate(new Date());
		saleSundriesData.setSaleTransactionData(saleTransactionData);
		return saleSundriesData;
	}

	private List<SaleRefundData> processRefund(List<RefundXml> refunds, SaleTransactionData saleTransactionData) {
		List<SaleRefundData> saleRefundDataList = new ArrayList<>();
		for (RefundXml refundXml : refunds) {
			saleRefundDataList.add(createSaleRefundData(refundXml, saleTransactionData));
		}
		return saleRefundDataList;
	}

	private SaleRefundData createSaleRefundData(RefundXml refundXml, SaleTransactionData saleTransactionData) {
		SaleRefundData saleRefundData = new SaleRefundData();
		saleRefundData.setSaleTransactionData(saleTransactionData);
		saleRefundData.setRefundReference(refundXml.getRefundReference());
		saleRefundData.setRefundStatus(refundXml.getRefundStatus());
		saleRefundData.setRefundAmount(Integer.valueOf(refundXml.getRefundItems().get(0).getRefundAmount()));
		saleRefundData.setCreatedDate(new Date());

		List<AdminFeeXml> adminFeeXml = refundXml.getAdminFees();
		if (CollectionUtils.isNotEmpty(adminFeeXml)) {
			saleRefundData.setAdminFee(adminFeeXml.get(0).getAmount());
		}
		return saleRefundData;
	}

	private List<SaleNonIssueData> processNonIssue(List<NonIssuesXml> nonIssuesXml,
			SaleTransactionData saleTransactionData) {
		List<SaleNonIssueData> saleNonIssueDataList = new ArrayList<>();
		for (NonIssuesXml nonIssueXml : nonIssuesXml) {
			saleNonIssueDataList.add(createSaleNonIssueData(nonIssueXml, saleTransactionData));
		}
		return saleNonIssueDataList;
	}

	private SaleNonIssueData createSaleNonIssueData(NonIssuesXml nonIssueXml, SaleTransactionData saleTransactionData) {
		SaleNonIssueData saleNonIssueData = new SaleNonIssueData();
		saleNonIssueData.setSaleTransactionData(saleTransactionData);
		saleNonIssueData.setNonIssueTransaction(nonIssueXml.getNonIssueTransaction());
		saleNonIssueData.setNonIssueDate(nonIssueXml.getNonIssueDate());
		saleNonIssueData.setOriginalIssueDate(nonIssueXml.getOriginalIssueDate());
		saleNonIssueData.setAmount(nonIssueXml.getAmount());
		saleNonIssueData.setOriginalTransactionNumber(nonIssueXml.getOriginalTransactionNumber());
		return saleNonIssueData;
	}

	private List<SaleTicketData> processTicket(List<TicketXml> ticketsXml, SaleTransactionData saleTransactionData) {
		List<SaleTicketData> saleTicketDataList = new ArrayList<>();
		for (TicketXml ticketXml : ticketsXml) {
			if (!isReservation(ticketXml)) {
				SaleTicketData saleTicketData = createSaleTicketData(ticketXml, saleTransactionData);
				saleTicketData.setSaleReservationData(
						getSaleReservationData(ticketsXml, saleTicketData, saleTransactionData));
				saleTicketDataList.add(saleTicketData);
			}
		}
		return saleTicketDataList;
	}

	private boolean isReservation(TicketXml ticketXml) {
		return "RS".equals(ticketXml.getProductType()) || "CP".equals(ticketXml.getProductType());
	}

	private SaleTicketData createSaleTicketData(TicketXml ticketXml, SaleTransactionData saleTransactionData) {
		SaleTicketData saleTicketData = new SaleTicketData();
		saleTicketData.setAmount(Integer.valueOf(ticketXml.getFareAmount()));
		saleTicketData.setTicketType(ticketXml.getTicketType());
		saleTicketData.setProductType(ticketXml.getProductType());
		saleTicketData.setOrigin(ticketXml.getOrigin());
		saleTicketData.setDestination(ticketXml.getDestination());
		saleTicketData.setTravelClass(ticketXml.getTravelClass());
		saleTicketData.setDiscountCode(ticketXml.getDiscountCode());
		saleTicketData.setDiscountPercent(Integer.valueOf(ticketXml.getDiscountPercent()));
		saleTicketData.setTransactionNumber(ticketXml.getTransactionNumber());
		saleTicketData.setRailCard(ticketXml.getRailCard());
		saleTicketData.setNumAdults(ticketXml.getNumAdults());
		saleTicketData.setNumChildren(ticketXml.getNumChildren());
		saleTicketData.setNumCoupons(Integer.valueOf(ticketXml.getNumCoupons()));
		saleTicketData.setCreatedDate(new Date());
		saleTicketData.setFulfilment(ticketXml.getFulfilment());
		saleTicketData.setFulfilmentRef(ticketXml.getFulfilmentRef());
		saleTicketData.setFulfilmentMethod(ticketXml.getFulfilmentMethod());
		saleTicketData.setPackageNumber(ticketXml.getPackageNumber());
		saleTicketData.setIssueDate(ticketXml.getIssueDate());
		saleTicketData.setMandatoryReservation(ticketXml.getMandatoryReservation());
		saleTicketData.setRoute(ticketXml.getRoute());
		saleTicketData.setOutwardDate(ticketXml.getOutwardDate());
		saleTicketData.setStatus(ticketXml.getStatus());
		saleTicketData.setETicketReference(ticketXml.getETicketReference());
		saleTicketData.setSaleTransactionData(saleTransactionData);
		return saleTicketData;
	}

	private List<SaleReservationData> getSaleReservationData(List<TicketXml> ticketsXml, SaleTicketData saleTicketData,
			SaleTransactionData saleTransactionData) {
		List<SaleReservationData> saleReservationDataList = new ArrayList<>();
		for (TicketXml reservationTicket : ticketsXml) {
			if (isReservation(reservationTicket)
					&& saleTicketData.getPackageNumber() == reservationTicket.getPackageNumber()) {
				SaleReservationData saleReservationData = mapTicketReservationDetails(reservationTicket,
						saleTransactionData);
				saleReservationData.setSaleTicketData(saleTicketData);
				saleReservationDataList.add(saleReservationData);
			}
		}
		return saleReservationDataList;
	}

	private SaleReservationData mapTicketReservationDetails(TicketXml reservationTicket,
			SaleTransactionData saleTransactionData) {
		SaleReservationData saleReservationData = new SaleReservationData();
		saleReservationData.setIssueDate(reservationTicket.getIssueDate());
		saleReservationData.setAmount(Integer.valueOf(reservationTicket.getFareAmount()));
		saleReservationData.setProductType(reservationTicket.getProductType());
		saleReservationData.setTicketType(reservationTicket.getTicketType());
		saleReservationData.setCreatedDateTime(new Date());
		saleReservationData.setSaleTransactionData(saleTransactionData);

		if (reservationTicket.getReservationDetails() != null) {
			ReservationDetailsXml reservationDetailsXml = reservationTicket.getReservationDetails();
			saleReservationData.setSupplCode(reservationDetailsXml.getSupplCode());
			saleReservationData.setGroupReservation(reservationDetailsXml.getGroupReservation());
		}
		return saleReservationData;
	}
}