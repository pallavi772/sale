package com.worldline.dts.sale.SpringBatchJDBC;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.worldline.dts.sale.dataaccess.SaleTransactionData;
import com.worldline.dts.sale.dataaccess.SaleTransactionDataRepository;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediate;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediateRepository;


@Component
public class SaleXmlWriter implements ItemWriter<SaleXmlAndTransactionData> {

    @Autowired
    private SaleTransactionDataRepository saleTransactionDataRepository ;

    @Autowired
    private SaleXmlIntermediateRepository saleXmlIntermediateRepository; // Repository to update SaleXmlIntermediate

    @Override
    @Transactional
    public void write(List<? extends SaleXmlAndTransactionData> saleXmlAndTransactionDataList) throws Exception {
        // Loop through each SaleXmlAndTransactionData and process
        for (SaleXmlAndTransactionData saleXmlAndTransactionData : saleXmlAndTransactionDataList) {
            SaleTransactionData saleTransactionData = saleXmlAndTransactionData.getSaleTransactionData();
            SaleXmlIntermediate saleXmlIntermediate = saleXmlAndTransactionData.getSaleXmlIntermediate();
            
            saleTransactionDataRepository.save(saleTransactionData);
            // Check if SaleTransactionData has all required fields populated
            if (!isValid(saleTransactionData)) {
                // If validation fails, set error state on SaleXmlIntermediate
                if (saleXmlIntermediate != null) {
                    saleXmlIntermediate.setIsProcessed(2); // Set to error state for child
                    saleXmlIntermediateRepository.save(saleXmlIntermediate);  // Save child in error state
                }
                System.err.println("SaleTransactionData has missing required fields, record skipped.");
                continue; // Skip to the next record
            }
            try {
              
                // After saving SaleTransactionData successfully, update isProcessed to 1 in SaleXmlIntermediate
                if (saleXmlIntermediate != null) {
                	 // saleXmlIntermediate.setIsProcessed(1); // Set to processed state
                      saleXmlIntermediateRepository.save(saleXmlIntermediate); 
                }
                
            }catch (DataIntegrityViolationException e) {
                // Handle specific constraint violations
                if (saleXmlIntermediate != null) {
                    saleXmlIntermediate.setIsProcessed(2); // Set to error state for child
                    saleXmlIntermediateRepository.save(saleXmlIntermediate); // Save child in error state
                }
                System.err.println("Data integrity violation while saving SaleTransactionData: " + e.getMessage());
        }
            catch (Exception e) {
            	  // Handle any other exceptions
                if (saleXmlIntermediate != null) {
                    saleXmlIntermediate.setIsProcessed(2); // Set to error state for child
                    saleXmlIntermediateRepository.save(saleXmlIntermediate); // Save child in error state
                }
                System.err.println("Failed to save SaleTransactionData: " + e.getMessage());
            }
        }}
    
    // Method to validate all required fields
    private boolean isValid(SaleTransactionData saleTransactionData) {
        if (saleTransactionData == null) {
            return false;
        }

        if (saleTransactionData.getClientId() == null || saleTransactionData.getClientId().equals("Unknown")) {
            System.err.println("Invalid ClientId: " + saleTransactionData.getClientId());
            return false;
        }
        if (saleTransactionData.getRetailChannel() == null || saleTransactionData.getRetailChannel().equals("Unknown")) {
            System.err.println("Invalid RetailChannel: " + saleTransactionData.getRetailChannel());
            return false;
        }
        return true;
    }



}

