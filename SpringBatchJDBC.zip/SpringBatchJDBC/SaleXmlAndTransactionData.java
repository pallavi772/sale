package com.worldline.dts.sale.SpringBatchJDBC;

import com.worldline.dts.sale.dataaccess.SaleTransactionData;
import com.worldline.dts.sale.dataaccess.SaleXmlIntermediate;

public class SaleXmlAndTransactionData {
    private SaleXmlIntermediate saleXmlIntermediate;
    private SaleTransactionData saleTransactionData;

    // Constructors, getters, setters
    public SaleXmlAndTransactionData(SaleXmlIntermediate saleXmlIntermediate, SaleTransactionData saleTransactionData) {
        this.saleXmlIntermediate = saleXmlIntermediate;
        this.saleTransactionData = saleTransactionData;
    }

    public SaleXmlIntermediate getSaleXmlIntermediate() {
        return saleXmlIntermediate;
    }

    public void setSaleXmlIntermediate(SaleXmlIntermediate saleXmlIntermediate) {
        this.saleXmlIntermediate = saleXmlIntermediate;
    }

    public SaleTransactionData getSaleTransactionData() {
        return saleTransactionData;
    }

    public void setSaleTransactionData(SaleTransactionData saleTransactionData) {
        this.saleTransactionData = saleTransactionData;
    }
}
