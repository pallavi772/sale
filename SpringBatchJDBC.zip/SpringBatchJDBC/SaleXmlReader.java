package com.worldline.dts.sale.SpringBatchJDBC;

import javax.sql.DataSource;

import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Component;

import com.worldline.dts.sale.dataaccess.SaleXmlIntermediate;

@Component
public class SaleXmlReader {

	@Autowired
	private DataSource dataSource;

	@Bean
	 JdbcCursorItemReader<SaleXmlIntermediate> reader() {
		JdbcCursorItemReader<SaleXmlIntermediate> reader = new JdbcCursorItemReader<>();
		reader.setDataSource(dataSource);
		reader.setSql(
				"SELECT TOP 10 * FROM sale_xml_intermediate where is_processed = 0 ");
		reader.setRowMapper(new BeanPropertyRowMapper<>(SaleXmlIntermediate.class));
		return reader;
	}

}

